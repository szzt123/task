#include "searchwindow.h"
#include <MyGlobalShortCut/MyGlobalShortCut.h>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    searchWindow w;

    MyGlobalShortCut *shortcut = new MyGlobalShortCut("Alt+Space",&w);
    QObject::connect(shortcut,SIGNAL(activated()),&w,SLOT(showHide()));
    w.show();

    return a.exec();
}
