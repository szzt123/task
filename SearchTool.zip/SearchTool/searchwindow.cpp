#include "searchwindow.h"
#include "ui_searchwindow.h"
#include<QStandardPaths>
#include<QDebug>
#include<QDir>
#include<QFileIconProvider>
#include<QMenu>
#include<QAction>
#include<QMessageBox>
#include<QDesktopServices>
#include<QUrl>
#include<QFileDialog>
#include <QClipboard>
#include<QKeyEvent>

#include"ZhToPY.h"

searchWindow::searchWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::searchWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("SunAo'fileSearch");


    //获取本地电脑桌面路径
    ui->lineEdit->setText(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation));


    //设置表格属性
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->verticalHeader()->setHidden(true);
    ui->tableWidget->setColumnWidth(0,280);
    ui->tableWidget->setColumnWidth(1,400);
    ui->tableWidget->setColumnWidth(2,100);
    QHeaderView* headerView = ui->tableWidget->horizontalHeader();
    headerView->setDefaultAlignment(Qt::AlignLeft);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    //初始化界面展示
    init();
    QDir pubDir("C:/Users/Public/Desktop");
    pubDir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries);
    QFileInfoList listPub=pubDir.entryInfoList();
    list<<listPub;
    hashFile.insert("",list);
    showFileInfo(list);


    //文件监控
    fileWatcher = new QFileSystemWatcher(this);
    fileWatcher->addPath(root);
    connect(fileWatcher,SIGNAL(directoryChanged(const QString&)),this,SLOT(dir_change_slot()));
    connect(fileWatcher,SIGNAL(fileChanged(const QString&)),this,SLOT(dir_change_slot()));

}

searchWindow::~searchWindow()
{
    delete ui;
}

void searchWindow::init()
{
    root=ui->lineEdit->text();
    QDir rootDir(root);//根目录
    rootDir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries);
//    QDir pubDir("C:/Users/Public/Desktop");
//    pubDir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries);
//    QFileInfoList listPub=pubDir.entryInfoList();
    list = rootDir.entryInfoList();
//    list<<listPub;

}

void searchWindow::showFileInfo(QFileInfoList showlist)
{

    QString numInfo="找到 "+QString::number(showlist.count())+" 个对象";
    ui->label->setText(numInfo);

    ui->tableWidget->setRowCount(0);
    int row=showlist.count();
    ui->tableWidget->setRowCount(row);
    for(int i=0; i<row ;i++)
    {
        QFileInfo tmpFileInfo = showlist.at(i);
        //
        QString fileName=tmpFileInfo.fileName();//文件名
        QString filePath=tmpFileInfo.canonicalPath(); //文件路径
        QString Size=QString::number(tmpFileInfo.size()/1024);//文件大小
        for(int j=Size.size()-3;j>0;j=j-3){
            Size.insert(j,',');
        }
        Size+=" KB";
        if(tmpFileInfo.isDir())
        {
            QFileIconProvider icon_provider;
            QIcon icon = icon_provider.icon(QFileIconProvider::Folder);
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(icon,fileName));
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(filePath));
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(""));
        }
        else if(tmpFileInfo.isFile())
        {
            QFileIconProvider icon_provider;
            QIcon icon = icon_provider.icon(tmpFileInfo);
            ui->tableWidget->setItem(i,0,new QTableWidgetItem(icon,fileName));
            ui->tableWidget->setItem(i,1,new QTableWidgetItem(filePath));
            ui->tableWidget->setItem(i,2,new QTableWidgetItem(Size));
        }
    }

    markChar();
}

QFileInfoList searchWindow::matchSearch(const QString &str,QFileInfoList tempList)
{
    if(str=="")return tempList;//防止搜索空字符顺序乱掉，直接返回

    QFileInfoList ret;
    QMultiMap<int,QFileInfo>m;//分类存储文件


    QString strEng=getEnglish(str);
    for(int i=0;i<tempList.size();i++)
    {
        QString fileName=tempList[i].fileName().toLower();
        QString EngName=getEnglish(tempList[i].fileName());
        if(EngName==strEng){//第一类--完全匹配
            m.insert(1,tempList[i]);
        }
        else if(fileName.contains(QRegExp("[\\x4e00-\\x9fa5]+"))){//如果有中文
            QString Ch=getChinese(fileName);//提取中文字符
            QString jp=ZhToPY::Instance()->zhToJP(Ch).toLower();
            if(EngName.contains(str)||fileName.contains(str)||Ch.contains(str)){ //第二类--首字母匹配
                m.insert(2,tempList[i]);
            }
            else if(jp.contains(str)){
                m.insert(3,tempList[i]);
            }
            else if(findChar(strEng,EngName)){
                m.insert(4,tempList[i]);
            }
        }
        else if(fileName.contains(str)){//第三类--包含字符串
            m.insert(3,tempList[i]);
        }
        else if(findChar(str,fileName)){//第四类--模糊匹配
            m.insert(4,tempList[i]);
        }
    }

    //读取排序好的文件数据
    for(auto it=m.begin();it!=m.end();it++){
        ret<<it.value();
    }

    return ret;
}

QString searchWindow::getChinese(QString str)
{
    QString chineseStr;
    int nCount = str.count();
    for(int i = 0 ; i < nCount ; i++)
    {
        QChar cha = str.at(i);
        ushort uni = cha.unicode();
        if(uni >= 0x4E00 && uni <= 0x9FA5)
        {
            chineseStr.append(uni);
        }
    }
    return chineseStr;  //最后返回的这个字符串就是中文字符串
}

QString searchWindow::getEnglish(QString str)
{
    QString ret;
    if(!str.contains(QRegExp("[\\x4e00-\\x9fa5]+"))){
        ret=str;
    }
    else{
        QString Ch=getChinese(str);//提取中文字符
        QString jp=ZhToPY::Instance()->zhToJP(Ch).toLower();

        int k=0;
        for(int j=0;j<str.size();j++)
        {
            if(str[j]==Ch[k]){
                ret.push_back(jp[k]);
                k++;
            }
            else
                ret.push_back(str[j]);
        }
    }

    return ret.toLower();
}

bool searchWindow::DelDir(const QString &path)
{
    if (path.isEmpty()){
        return false;
    }
    QDir dir(path);
    if(!dir.exists()){
        return true;
    }
    dir.setFilter(QDir::AllEntries | QDir::NoDotAndDotDot); //设置过滤
    QFileInfoList fileList = dir.entryInfoList(); // 获取所有的文件信息
    foreach (QFileInfo file, fileList){ //遍历文件信息
        if (file.isFile()){ // 是文件，删除
            file.dir().remove(file.fileName());
        }else{ // 递归删除
            DelDir(file.absoluteFilePath());
        }
    }
    return dir.rmpath(dir.absolutePath()); // 删除文件夹

}

bool searchWindow::findChar(const QString &str, const QString &name)
{
    int k=0;
    for(int j=0;j<name.size()&&k<str.size();j++){
        if(name[j]==str[k]){
            k++;
        }
    }
    if(k==str.size()){
        return true;
    }
    return false;
}

void searchWindow::markChar()
{
    QString str=ui->searchEdit->text().toLower();
    if(str=="")
        return ;


    for(int i=0;i<hashFile[ui->searchEdit->text()].size();i++){
        QString markName="";
        QString fileName=hashFile[ui->searchEdit->text()][i].fileName();
        int k=0;
        for(int j=0;j<fileName.size();j++){
            QString Engchar=ZhToPY::Instance()->zhToJP(QString(fileName[j])).toLower();
            if((fileName[j]==str[k]||Engchar==str[k])&&k<str.size()){
                markName+=("<font color=violet><b>"+QString(fileName[j])+"</b></font>");
                k++;
            }
            else
            {
                markName.push_back(fileName[j]);
            }
        }
        this->ui->tableWidget->item(i,0)->setText("");
        QLabel* label=new QLabel(markName,this);
        QFont font;
        font.setFamily("Microsoft YaHei");
        label->setFont(font);
        this->ui->tableWidget->setCellWidget(i,0,label);
    }
}




void searchWindow::on_searchEdit_textChanged(const QString arg)
{
    if(hashFile.find(arg)==hashFile.end()){
        auto it=hashFile.begin();
        for(;it!=hashFile.end();it++){
            if(arg.contains(it.key())){
                hashFile[arg]=matchSearch(arg,it.value());
                break;
            }
        }
        if(it==hashFile.end())
            hashFile[arg]=matchSearch(arg,list);
    }
    showFileInfo(hashFile[arg]);
}

void searchWindow::on_tableWidget_customContextMenuRequested(const QPoint &pos)
{
    //qDebug()<<pos.x()<<" "<<pos.y();
    //获得鼠标点击的x，y坐标点
    int x = pos.x ();
    int y = pos.y ();
    QModelIndex index = ui->tableWidget->indexAt (QPoint(x,y));
    int row = index.row ();//获得QTableWidget列表点击的行数
    int col=index.column();


    //qDebug()<<row<<" "<<col;
    //设置菜单选项
    if(col==0){
        QMenu *menu = new QMenu(ui->tableWidget);
        QAction *pnew1 = new QAction("打开(O)",ui->tableWidget);
        //pnew1->setShortcut(QKeySequence::Open);
        QAction *pnew2 = new QAction("删除(D)",ui->tableWidget);
        connect (pnew1,&QAction::triggered,this,[=](){
            QDesktopServices::openUrl(QUrl::fromLocalFile(hashFile[ui->searchEdit->text()][row].canonicalFilePath()));
        });
        connect (pnew2,&QAction::triggered,this,[=](){
            QMessageBox:: StandardButton ret = QMessageBox::question(this,"提示","确定删除该文件？",QMessageBox::Yes | QMessageBox::No);
            if(ret==QMessageBox::Yes){
                QFileInfo tmpInfo=hashFile[ui->searchEdit->text()][row];
                if(tmpInfo.isDir()){
                    DelDir(tmpInfo.absoluteFilePath());
                }
                else if(tmpInfo.isFile()){
                    tmpInfo.dir().remove(tmpInfo.fileName());
                }
            }
        });
        menu->addAction(pnew1);
        menu->addSeparator();
        menu->addAction(pnew2);
        //menu->move (cursor ().pos ());
        //menu->show ();
        menu->exec(QCursor::pos());
    }
    else if(col==1){
        QMenu *menu = new QMenu(ui->tableWidget);
        QAction *pnew1 = new QAction("复制(C)",ui->tableWidget);
        QAction *pnew2 = new QAction("转到(T)",ui->tableWidget);
        connect (pnew1,&QAction::triggered,this,[=](){
            QClipboard *clipboard = QApplication::clipboard();
            QString str_text = ui->tableWidget->item(row,col)->text();
            clipboard->setText(str_text);
        });
        connect (pnew2,&QAction::triggered,this,[=](){
            QDesktopServices::openUrl(QUrl::fromLocalFile(ui->tableWidget->item(row,col)->text()));
        });
        menu->addAction(pnew1);
        menu->addSeparator();
        menu->addAction(pnew2);
        menu->exec(QCursor::pos());
    }

}

void searchWindow::showHide()
{
    if(isShow)
        hide();
    else
        show();

    isShow=!isShow;

}


void searchWindow::on_tableWidget_cellDoubleClicked(int row, int column)
{
    if(column==0)
    {
        QDesktopServices::openUrl(QUrl::fromLocalFile(hashFile[ui->searchEdit->text()][row].canonicalFilePath()));
    }

}

void searchWindow::dir_change_slot()
{
    //更新fileArray的信息
    init();
    hashFile.clear();
    hashFile.insert(ui->searchEdit->text(),matchSearch(ui->searchEdit->text(),list));
    showFileInfo(hashFile[ui->searchEdit->text()]);
}

void searchWindow::keyPressEvent(QKeyEvent *event)
{
    if(c==0&&event->key()==Qt::Key_Delete){
        QMessageBox:: StandardButton ret = QMessageBox::question(this,"提示","确定删除该文件？",QMessageBox::Yes | QMessageBox::No);
        if(ret==QMessageBox::Yes){
            QFileInfo tmpInfo=hashFile[ui->searchEdit->text()][r];
            if(tmpInfo.isDir()){
                DelDir(tmpInfo.absoluteFilePath());
            }
            else if(tmpInfo.isFile()){
                tmpInfo.dir().remove(tmpInfo.fileName());
            }
        }
    }
}

void searchWindow::on_tableWidget_cellClicked(int row, int column)
{
    r=row;
    c=column;
}


void searchWindow::on_pushButton_clicked()
{
    QString file_path = QFileDialog::getExistingDirectory(this,"请选择文件夹",root);
    ui->lineEdit->setText(file_path);
    init();
    hashFile.clear();
    hashFile.insert(ui->searchEdit->text(),matchSearch(ui->searchEdit->text(),list));
    showFileInfo(hashFile[ui->searchEdit->text()]);

}
