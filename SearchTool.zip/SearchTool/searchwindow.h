#ifndef SEARCHWINDOW_H
#define SEARCHWINDOW_H

#include <QWidget>
#include<QFileInfoList>
#include<QFileSystemWatcher>
#include<QLabel>
#include<QHash>

QT_BEGIN_NAMESPACE
namespace Ui { class searchWindow; }
QT_END_NAMESPACE

class searchWindow : public QWidget
{
    Q_OBJECT

public:
    searchWindow(QWidget *parent = nullptr);
    ~searchWindow();

    void init();
    void showFileInfo(QFileInfoList);//显示信息
    QFileInfoList matchSearch(const QString& str,QFileInfoList tempList);//搜索匹配
    QString getChinese(QString str);//获取中文字符
    QString getEnglish(QString str);//将字符串统一成非中文字符
    bool DelDir(const QString &path);//删除文件夹
    bool findChar(const QString& str,const QString& name);//查找字符匹配

    void markChar();//标记搜索关键字

private slots:
    void on_searchEdit_textChanged(const QString );
    void on_tableWidget_customContextMenuRequested(const QPoint &pos);
    void showHide();
    void on_tableWidget_cellDoubleClicked(int row, int column);
    void dir_change_slot();
    void on_tableWidget_cellClicked(int row, int column);

    void on_pushButton_clicked();

protected:
    void keyPressEvent(QKeyEvent *event);
    int r,c;
private:
    Ui::searchWindow *ui;
    QString root;//根目录
    QFileInfoList list;//根目录文件列表
    QFileSystemWatcher* fileWatcher;//文件监控
    bool isShow=false;//
    QHash<QString,QFileInfoList> hashFile;//储存每一步搜索结果的数组

};


#endif // SEARCHWINDOW_H
